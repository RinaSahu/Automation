package gurukula.qa.pages;

import gurukula.qa.base.TestBase;

public class SearchStaffPage extends TestBase{

}
