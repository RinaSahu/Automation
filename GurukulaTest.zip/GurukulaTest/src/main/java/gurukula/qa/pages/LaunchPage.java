package gurukula.qa.pages;

	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
	import gurukula.qa.base.TestBase;
	import gurukula.qa.util.GKConstants;

	public class LaunchPage extends TestBase{

		//PageFactory - OR
		@FindBy(xpath=GKConstants.GKHOME_LOGO)
		public WebElement gklogo;
		
		@FindBy(xpath=GKConstants.GKHOME_TITLE)
		public WebElement gktitle;
		
		@FindBy(xpath=GKConstants.LOGIN_LINK)
		public WebElement loginlink;
		
		@FindBy(xpath=GKConstants.REGISTER_LINK)
		public WebElement registerlink;
		
		@FindBy(xpath=GKConstants.HOME_MENU)
		public WebElement homemenu;
		
		@FindBy(xpath=GKConstants.ACCOUNT_MENU)
		public WebElement accountmenu;
		
		//Initialization of Page Objects
		public LaunchPage(){
			PageFactory.initElements(driver, this);
		}
		
		//Actions
		public String validateLaunchPageTitle() {
			return driver.getTitle();
		}
		
		public boolean validateLoginPageTitle() {
			return gktitle.isDisplayed();
		}
		
		public boolean validateGKLogo() {
			return gklogo.isDisplayed();
		}
		
		
		public boolean validateHomeMenu() {
			return homemenu.isDisplayed();
		}
		
		public boolean validateAccountMenu() {
			return accountmenu.isDisplayed();
		}
		
		public boolean validateloginLink() {
			return loginlink.isDisplayed();
		}	
		
		public boolean validateRegisterLink() {
			return registerlink.isDisplayed();
		}
		
		public LoginPage gotologin() {
			loginlink.click();
			return new LoginPage();
	}
		
		public RegistrationPage gotoRegister() {
			registerlink.click();
			return new RegistrationPage();
	}
		
}		
		



