package gurukula.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//import org.testng.Assert;

import gurukula.qa.base.*;
import gurukula.qa.util.*;


public class GeneralSettingsPage extends TestBase{

		@FindBy(xpath=GKConstants.SETTINGS_TITLE)
		public WebElement settingstitle;
		
		@FindBy(xpath=GKConstants.FIRST_NAME)
		public WebElement firstnm;
		
		@FindBy(xpath=GKConstants.LAST_NAME)
		public WebElement lastnm;
		
		@FindBy(xpath=GKConstants.EMAIL_ID)
		public WebElement email;
		
		@FindBy(xpath=GKConstants.LANGUAGE)
		public WebElement langs;
		
		@FindBy(xpath=GKConstants.SAVE_CHANGES)
		public WebElement saveChanges;
		
		@FindBy(xpath=GKConstants.SUCCESS_STATUS)
		public WebElement success;
		
		@FindBy(xpath=GKConstants.FAILURE_STATUS)
		public WebElement failure;
		
		//*Initialization of Page Objects
		public GeneralSettingsPage(){
			PageFactory.initElements(driver, this);
				}		
		
		//Actions
		
		public String validateSettingPageTitle() {
			return driver.getTitle();
		}
				
		public GeneralSettingsPage doSettingsChange(String nfirstnm,String nlastnm, String nemail, String nlangs) {
			firstnm.sendKeys(nfirstnm);
			lastnm.sendKeys(nlastnm);
			email.sendKeys(nemail);
			langs.sendKeys(nlangs);
			saveChanges.click();
			return new GeneralSettingsPage();
			
	}

		
					
}

