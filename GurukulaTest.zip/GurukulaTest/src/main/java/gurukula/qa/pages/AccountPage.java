	package gurukula.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import gurukula.qa.base.TestBase;
import gurukula.qa.util.GKConstants;

public class AccountPage extends TestBase{
	
	//PageFactory - OR	
	
		@FindBy(xpath=GKConstants.ACCOUNTHOME_TITLE)
		public WebElement accounthometitle;
		
		@FindBy(xpath=GKConstants.HOME_MENU)
		public WebElement homelink;
		
		@FindBy(xpath=GKConstants.ENTITIES_MENU)
		public WebElement entitieslink;
		
		@FindBy(xpath=GKConstants.ACCOUNT_MENU)
		public WebElement accountlink;
		
		@FindBy(xpath=GKConstants.GKHOME_LOGO)
		public WebElement aclogo;
		
		//Initialization of Page Objects
		public AccountPage(){
			PageFactory.initElements(driver, this);
		}
		
		//Actions
		public String validateAccountPageTitle() {
			return driver.getTitle();
		}
		
		public boolean validateAccountPageHeader() {
			return accounthometitle.isDisplayed();
		}
		
		public boolean validateAccountPageLogo() {
			return aclogo.isDisplayed();
		}
		
		public AccountPage clickHomeMenu() {
			homelink.click();
			return new AccountPage();
		}
		
		
		public EntitiesPage clickEntitiesMenu() {
			entitieslink.click();
			return new EntitiesPage();
		}
			
		public AccountMenuPage clickAccountMenu() {
			accountlink.click();
			return new AccountMenuPage();
		}
		



}
