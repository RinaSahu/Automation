package gurukula.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import gurukula.qa.base.TestBase;
import gurukula.qa.util.GKConstants;

public class NewStaffPage extends TestBase{
	
	//PageFactory - OR	
	
	@FindBy(xpath=GKConstants.NEWSTAFF_TITLE)
	public WebElement newstafftitle;
	
	@FindBy(xpath=GKConstants.NEWSTAFF_NAME)
	public WebElement newstaffname;
	
	@FindBy(xpath=GKConstants.NEWSTAFF_BRANCH)
	public WebElement newstaffbranch;
	
	@FindBy(xpath=GKConstants.SAVE_BUTTON)
	public WebElement savebutton;
	
	@FindBy(xpath=GKConstants.CANCEL_BUTTON)
	public WebElement cancelbutton;
	
	
	//Initialization of Page Objects
	public NewStaffPage(){
		PageFactory.initElements(driver, this);
	}
	
	//Actions
							
	public String validateNewStaffModalTitle() {
			return newstafftitle.getText();
	}
		
	public StaffPage doStaffCreation(String staffname, String branchname) {
		newstaffname.sendKeys(staffname);
		Select dropdown = new Select(driver.findElement(By.xpath(GKConstants.NEWSTAFF_BRANCH)));
		//dropdown.deselectByValue(branchname);
		dropdown.selectByVisibleText(branchname); 
		savebutton.click();
		return new StaffPage();
		}
	
		public StaffPage doStaffCreationCancel(String staffname, String branchname) {
		newstaffname.sendKeys(staffname);
		Select dropdown = new Select(driver.findElement(By.xpath(GKConstants.NEWSTAFF_BRANCH)));
		dropdown.selectByVisibleText(branchname); 
		cancelbutton.click();
		return new StaffPage();
	}

}
