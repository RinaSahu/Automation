package gurukula.qa.pages;

public class StaffDeleteConfirmPage {

}
