package gurukula.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import gurukula.qa.base.TestBase;
import gurukula.qa.util.GKConstants;

public class BranchEditPage extends TestBase{
	
	//PageFactory - OR	
	
	@FindBy(xpath=GKConstants.NEWBRANCH_TITLE)
	public WebElement editbranchtitle;
	
	@FindBy(xpath=GKConstants.NEWBRANCH_NAME)
	public WebElement editbranchname;
	
	@FindBy(xpath=GKConstants.NEWBRANCH_CODE)
	public WebElement editbranchcode;
	
	@FindBy(xpath=GKConstants.BRSAVE_BUTTON)
	public WebElement savebutton;
	
	@FindBy(xpath=GKConstants.BRCANCEL_BUTTON)
	public WebElement cancelbutton;
	
	
	//Initialization of Page Objects
	public BranchEditPage(){
		PageFactory.initElements(driver, this);
	}
	
	//Actions
							
	public String validateEditBranchModalTitle() {
			return editbranchtitle.getText();
	}
		
	public BranchPage doBranchCreation(String Branchname, String Branchcode) {
		editbranchname.sendKeys(Branchname);
		editbranchcode.sendKeys(Branchcode);
		savebutton.click();
		return new BranchPage();
		}
	
		public BranchPage doBranchCreationCancel(String Branchname, String Branchcode) {
		editbranchname.sendKeys(Branchname);
		editbranchcode.sendKeys(Branchcode);
		cancelbutton.click();
		return new BranchPage();
	}

}
