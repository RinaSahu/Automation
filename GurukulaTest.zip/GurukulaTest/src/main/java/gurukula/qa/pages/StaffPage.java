	package gurukula.qa.pages;

	//import java.awt.List;

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
	//import org.testng.Assert;

	import gurukula.qa.base.TestBase;
	import gurukula.qa.util.GKConstants;

	public class StaffPage extends TestBase{
		
			//PageFactory - OR	
			
				
				@FindBy(xpath=GKConstants.STAFF_TITLE)
				public WebElement stafftitle;
				
				@FindBy(xpath=GKConstants.NEWSTAFF_LINK)
				public WebElement newstafflink;
				
				@FindBy(xpath=GKConstants.STQUERY_VALUE)
				public WebElement staffquery;
				
				@FindBy(xpath=GKConstants.STSEARCH_LINK)
				public WebElement staffquerylink;
				
				
				@FindBy(xpath=GKConstants. STSEARCH_PAGE)
				public WebElement staffsearchpage;
				
				
				@FindBy(xpath=GKConstants.VIEW_LINK)
				public WebElement staffviewbutton;
				
				@FindBy(xpath=GKConstants.EDIT_LINK)
				public WebElement staffeditbutton;
				
				@FindBy(xpath=GKConstants.DELETE_LINK)
				public WebElement staffdeletebutton;
				
				@FindBy(xpath=GKConstants.STAFF_PAGINATION)
				public WebElement staffpagerlink;
				
				@FindBy(xpath=GKConstants.STAFF_PAGER)
				public WebElement staffpager;
				
				@FindBy(xpath=GKConstants.STAFF_ID)
				public WebElement staffid;
				
				@FindBy(xpath=GKConstants.STAFF_COUNT)
				public WebElement staffcount;
				
						
				//Initialization of Page Objects
				public StaffPage(){
					PageFactory.initElements(driver, this);
				}
				
				//Actions
				
				public String validateStaffPageTitle() {
					return driver.getTitle();
				}
				public boolean validateStaffPageHeader() {
					return stafftitle.isDisplayed();
				}
							
									
				public NewStaffPage validateNewStaffLink() {
					newstafflink.click();
					return new NewStaffPage();
				}
				
				public SearchStaffPage doStaffSearch(String query) {
					staffquery.sendKeys(query);
					staffquerylink.click();
					return new SearchStaffPage();
				}
				
				public StaffViewPage validateStaffViewButton() {
					staffviewbutton.click();
					return new StaffViewPage();
				}
				
				public StaffEditPage validateStaffEditButton() {
					staffeditbutton.click();
					return new StaffEditPage();
				}
				
				public StaffDeleteConfirmPage validateStaffDeleteButton() {
					staffdeletebutton.click();
					return new StaffDeleteConfirmPage();
				}
				
				public StaffViewPage validateStaffidButton() {
					staffid.click();
					return new StaffViewPage();
				}
				
				public StaffPage validateStaffPagination() {
					staffpagerlink.click();
					return new StaffPage();
				}
				
				public boolean validateStaffPager() {
					return staffpager.isDisplayed();
				}
				
				public int findLastID() {
				//	int rowsize = ;
				int count = driver.findElements(By.xpath(GKConstants.STAFF_COUNT)).size();
					//int count = rows.size();
					System.out.println("Staff ID : " +count);
					//for(WebElement e : rows) {
				      //  Assert.assertEquals("autostaff", e.getText());
				   // }
					return count;
				}
				
		}