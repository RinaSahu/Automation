package gurukula.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import gurukula.qa.base.TestBase;
import gurukula.qa.util.GKConstants;

public class NewBranchPage extends TestBase{
	
	//PageFactory - OR	
	
	@FindBy(xpath=GKConstants.NEWBRANCH_TITLE)
	public WebElement newbranchtitle;
	
	@FindBy(xpath=GKConstants.NEWBRANCH_NAME)
	public WebElement newbranchname;
	
	@FindBy(xpath=GKConstants.NEWBRANCH_CODE)
	public WebElement newbranchcode;
	
	@FindBy(xpath=GKConstants.BRSAVE_BUTTON)
	public WebElement savebutton;
	
	@FindBy(xpath=GKConstants.BRCANCEL_BUTTON)
	public WebElement cancelbutton;
	
	
	//Initialization of Page Objects
	public NewBranchPage(){
		PageFactory.initElements(driver, this);
	}
	
	//Actions
							
	public String validateNewBranchModalTitle() {
			return newbranchtitle.getText();
	}
		
	public BranchPage doBranchCreation(String Branchname, String Branchcode) {
		newbranchname.sendKeys(Branchname);
		newbranchcode.sendKeys(Branchcode);
		savebutton.click();
		return new BranchPage();
		}
	
		public BranchPage doBranchCreationCancel(String Branchname, String Branchcode) {
		newbranchname.sendKeys(Branchname);
		newbranchcode.sendKeys(Branchcode);
		cancelbutton.click();
		return new BranchPage();
	}

}
