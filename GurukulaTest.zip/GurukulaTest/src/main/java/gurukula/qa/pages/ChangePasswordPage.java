package gurukula.qa.pages;

    import gurukula.qa.base.TestBase;

    import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
	//import org.testng.Assert;

	import gurukula.qa.util.*;

	public class ChangePasswordPage extends TestBase{
		   
			@FindBy(xpath=GKConstants.PASSWORD_TITLE)
			public WebElement passwordtitle;
			
			@FindBy(xpath=GKConstants.NEW_PASSWORD)
			public WebElement newpassword;
			
			@FindBy(xpath=GKConstants.CONFIRM_PASSWORD)
			public WebElement confirmpassword;
								
			@FindBy(xpath=GKConstants.SAVE_CHANGES)
			public WebElement saveChanges;
			
			@FindBy(xpath=GKConstants.SUCCESS_STATUS)
			public WebElement success;
			
			@FindBy(xpath=GKConstants.FAILURE_STATUS)
			public WebElement failure;
			
			//*Initialization of Page Objects
			public ChangePasswordPage(){
				PageFactory.initElements(driver, this);
					}		
			
			//Actions
			
			public String validatePassowordPageTitle() {
				return driver.getTitle();
			}
					
			public ChangePasswordPage doPasswordChange(String newpwd ,String cnfpwd) {
				newpassword.sendKeys(newpwd);
				confirmpassword.sendKeys(cnfpwd);
				saveChanges.click();
				return new ChangePasswordPage();
				
		}

			
						
	}


