	package gurukula.qa.pages;

	//import java.awt.List;

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
	//import org.testng.Assert;

	import gurukula.qa.base.TestBase;
	import gurukula.qa.util.GKConstants;

	public class BranchPage extends TestBase{
		
			//PageFactory - OR	
			
				
				@FindBy(xpath=GKConstants.BRANCHES_TITLE)
				public WebElement branchtitle;
				
				@FindBy(xpath=GKConstants.NEWBRANCHES_LINK)
				public WebElement newbranchlink;
				
				@FindBy(xpath=GKConstants.BRQUERY_VALUE)
				public WebElement branchquery;
				
				@FindBy(xpath=GKConstants.BRSEARCH_LINK)
				public WebElement branchquerylink;
				
				
				@FindBy(xpath=GKConstants. BRSEARCH_PAGE)
				public WebElement branchsearchpage;
				
				
				@FindBy(xpath=GKConstants.BRVIEW_LINK)
				public WebElement branchviewbutton;
				
				@FindBy(xpath=GKConstants.EDIT_LINK)
				public WebElement brancheditbutton;
				
				@FindBy(xpath=GKConstants.DELETE_LINK)
				public WebElement branchdeletebutton;
				
				@FindBy(xpath=GKConstants.BRANCH_PAGINATION)
				public WebElement branchpagerlink;
				
				@FindBy(xpath=GKConstants.BRANCH_PAGER)
				public WebElement branchpager;
				
				@FindBy(xpath=GKConstants.BRANCH_ID)
				public WebElement branchid;
				
				@FindBy(xpath=GKConstants.BRANCH_COUNT)
				public WebElement branchcount;
				
						
				//Initialization of Page Objects
				public BranchPage(){
					PageFactory.initElements(driver, this);
				}
				
				//Actions
				
				public String validateBranchPageTitle() {
					return driver.getTitle();
				}
				public boolean validateBranchPageHeader() {
					return branchtitle.isDisplayed();
				}
							
									
				public NewBranchPage validateNewBranchLink() {
					newbranchlink.click();
					return new NewBranchPage();
				}
				
				public SearchBranchPage doBranchSearch(String query) {
					branchquery.sendKeys(query);
					branchquerylink.click();
					return new SearchBranchPage();
				}
				
				public BranchViewPage validateBranchViewButton() {
					branchviewbutton.click();
					return new BranchViewPage();
				}
				
				public BranchEditPage validateBranchEditButton() {
					brancheditbutton.click();
					return new BranchEditPage();
				}
				
				public BranchDeleteConfirmPage validateBranchDeleteButton() {
					branchdeletebutton.click();
					return new BranchDeleteConfirmPage();
				}
				
				public BranchViewPage validateBranchidButton() {
					branchid.click();
					return new BranchViewPage();
				}
				
				public BranchPage validateBranchPagination() {
					branchpagerlink.click();
					return new BranchPage();
				}
				
				public boolean validateBranchPager() {
					return branchpager.isDisplayed();
				}
				
				public int findLastID() {
				//	int rowsize = ;
				int count = driver.findElements(By.xpath(GKConstants.BRANCH_COUNT)).size();
					//int count = rows.size();
					System.out.println("BRANCH ID : " +count);
					//for(WebElement e : rows) {
				      //  Assert.assertEquals("autoBRANCH", e.getText());
				   // }
					return count;
				}
				
		}