package gurukula.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import gurukula.qa.base.TestBase;
import gurukula.qa.util.GKConstants;

public class LoginPage extends TestBase{

	//PageFactory - OR
	
	@FindBy(xpath=GKConstants.LPHOME_LOGO)
	public WebElement lplogo;
	
	@FindBy(xpath=GKConstants.LOGIN_TITLE)
	public WebElement loginHeader;
	
	@FindBy(xpath=GKConstants.LOGIN_USERNAME)
	public WebElement username;
	
	@FindBy(xpath=GKConstants.LOGIN_PASSWORD)
	public WebElement password;
	
	@FindBy(xpath=GKConstants.AUTHENTICATE_BUTTON)
	public WebElement AuthenticateButton;
	
	//*Initialization of Page Objects
	public LoginPage(){
		PageFactory.initElements(driver, this);
			}
	
	//Actions
	public String validateLoginPageTitle() {
		return driver.getTitle();
	}
	
	public boolean validateLoginPageHeader() {
		return loginHeader.isDisplayed();
	}
	
	public boolean validateLogo() {
		return lplogo.isDisplayed();
	}
	
	public AccountPage doLogin(String usernm, String pwd) {
		username.sendKeys(usernm);
		password.sendKeys(pwd);
		AuthenticateButton.click();
		return new AccountPage();
	}
	
}
	

