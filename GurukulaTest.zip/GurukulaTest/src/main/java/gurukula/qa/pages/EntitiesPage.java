	package gurukula.qa.pages;

	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
    import gurukula.qa.base.TestBase;
	import gurukula.qa.pages.EntitiesPage;
	import gurukula.qa.util.GKConstants;

	public class EntitiesPage extends TestBase{
		
			//PageFactory - OR	
			
				@FindBy(xpath=GKConstants.BRANCH_LINK)
				public WebElement branchlink;
				
				@FindBy(xpath=GKConstants.STAFF_LINK)
				public WebElement stafflink;
				
				
				//Initialization of Page Objects
				public EntitiesPage(){
					PageFactory.initElements(driver, this);
				}
				
				//Actions
										
				public BranchPage validateBranchLink() {
					branchlink.click();
					return new BranchPage();
				}
					
				public StaffPage validateStaffLink() {
					
					stafflink.click();
					return new StaffPage();
				}
		}