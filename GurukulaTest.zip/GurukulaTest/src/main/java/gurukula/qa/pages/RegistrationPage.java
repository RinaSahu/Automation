package gurukula.qa.pages;

	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;

	import gurukula.qa.base.TestBase;
	import gurukula.qa.util.GKConstants;

	public class RegistrationPage extends TestBase{

		//PageFactory - OR
		
		@FindBy(xpath=GKConstants.RGHOME_LOGO )
		public WebElement regiterlogo;
		
		@FindBy(xpath=GKConstants.REGISTER_TITLE )
		public WebElement registertitle;
		
		@FindBy(xpath=GKConstants.REG_LOGIN )
		public WebElement registerlogin;
					
		@FindBy(xpath=GKConstants.REG_EMAILID)
		public WebElement registeremail;
		
		@FindBy(xpath=GKConstants.NEW_PWD)
		public WebElement registerpwd;
		
		@FindBy(xpath=GKConstants.CONF_PWD)
		public WebElement registerconfpwd;
		
		@FindBy(xpath=GKConstants.REGISTER_BUTTON)
		public WebElement registerbutton;
		
		//*Initialization of Page Objects
		public RegistrationPage(){
			PageFactory.initElements(driver, this);
				}
		
		//Actions
		public String validateregisterPageTitle() {
			return driver.getTitle();
		}
		
		public boolean validateregisterPageHeader() {
			return registertitle.isDisplayed();
		}
		
		public boolean validateregLogo() {
			return regiterlogo.isDisplayed();
		}
		
		public NewAccountPage doregister(String login, String email, String password, String confirmpwd) {
			registerlogin.sendKeys(login);
			registeremail.sendKeys(email);
			registerpwd.sendKeys(password);
			registerconfpwd.sendKeys(confirmpwd);
			registerbutton.click();
			return new NewAccountPage();
		}
		
	}
		

