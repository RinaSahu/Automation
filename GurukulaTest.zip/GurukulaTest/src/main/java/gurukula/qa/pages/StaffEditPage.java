package gurukula.qa.pages;

	import gurukula.qa.base.TestBase;
	import org.openqa.selenium.By;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
	import org.openqa.selenium.support.ui.Select;

	import gurukula.qa.util.GKConstants;

	public class StaffEditPage extends TestBase{

		
		//PageFactory - OR	
		
		@FindBy(xpath=GKConstants.NEWSTAFF_TITLE)
		public WebElement editstafftitle;
		
		@FindBy(xpath=GKConstants.NEWSTAFF_NAME)
		public WebElement editstaffname;
		
		@FindBy(xpath=GKConstants.NEWSTAFF_BRANCH)
		public WebElement editstaffbranch;
		
		@FindBy(xpath=GKConstants.SAVE_BUTTON)
		public WebElement savebutton;
		
		@FindBy(xpath=GKConstants.CANCEL_BUTTON)
		public WebElement cancelbutton;
		
		
		//Initialization of Page Objects
		public StaffEditPage(){
			PageFactory.initElements(driver, this);
		}
		
		//Actions
								
		public String validateEditStaffModalTitle() {
				return editstafftitle.getText();
		}
			
		public StaffPage doStaffEdit(String staffname, String branchname) {
			editstaffname.sendKeys(staffname);
			Select dropdown = new Select(driver.findElement(By.xpath(GKConstants.NEWSTAFF_BRANCH)));
			//dropdown.deselectByValue(branchname);
			dropdown.selectByVisibleText(branchname); 
			savebutton.click();
			return new StaffPage();
			}
		
			public StaffPage doStaffEditCancel(String staffname, String branchname) {
			editstaffname.sendKeys(staffname);
			Select dropdown = new Select(driver.findElement(By.xpath(GKConstants.NEWSTAFF_BRANCH)));
			dropdown.selectByVisibleText(branchname); 
			cancelbutton.click();
			return new StaffPage();
		}

	}

