package gurukula.qa.pages;

public class BranchViewPage {

}
