package gurukula.qa.pages;

import gurukula.qa.base.TestBase;

public class SessionPage extends TestBase{

}
