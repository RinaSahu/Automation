package gurukula.qa.pages;

public class BranchDeleteConfirmPage {

}
