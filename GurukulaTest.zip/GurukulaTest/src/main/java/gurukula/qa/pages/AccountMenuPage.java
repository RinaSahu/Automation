package gurukula.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import gurukula.qa.base.TestBase;
import gurukula.qa.util.GKConstants;

public class AccountMenuPage extends TestBase{
	
	//PageFactory - OR	
	
		@FindBy(xpath=GKConstants.SETTINGS_LINK)
		public WebElement settingslink;
		
		@FindBy(xpath=GKConstants.PASSWORD_LINK)
		public WebElement passwordlink;
		
		@FindBy(xpath=GKConstants.SESSION_LINK)
		public WebElement sessionlink;
		
		@FindBy(xpath=GKConstants.LOGOUT_LINK)
		public WebElement logoutlink;
		
		
		
		//Initialization of Page Objects
		public AccountMenuPage(){
			PageFactory.initElements(driver, this);
		}
		
		//Actions
		
			
		public GeneralSettingsPage clickSettingslink() {
			settingslink.click();
			return new GeneralSettingsPage();
		}
		
		
		public ChangePasswordPage clickPasswordLink() {
			passwordlink.click();
			return new ChangePasswordPage();
		}
			
		public SessionPage clickSessionLink() {
			sessionlink.click();
			return new SessionPage();
		}
		
		public LaunchPage clickLogoutLink() {
			logoutlink.click();
			return new LaunchPage();
		}


}
