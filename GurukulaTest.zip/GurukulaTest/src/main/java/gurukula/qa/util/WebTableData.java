package gurukula.qa.util;

import java.util.ArrayList;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class WebTableData {

		public ArrayList<HashMap<String, String>> _data;

		public WebTableData(ArrayList<HashMap<String, String>> data) {
		    _data = data;
		}

		    public static WebTableData get_SiteTable_ByCell(WebDriver driver, By tableCells, String[] headerValues) {
		   // ArrayList<WebElement> tableCellElements = new ArrayList<WebElement>(driver.findElements(tableCells));

		    ArrayList<HashMap<String, String>> data = new ArrayList<HashMap<String, String>>();

		   /* int numberRows = tableCellElements.size() / headerValues.length;

		    for (int i = 0; i < numberRows; ) {

		        HashMap<String, String> newRow = new HashMap<>();
		        for (int j = 0; j < headerValues.length; j++, i++) {
		            newRow.put(headerValues[j], tableCellElements.get(i).getText());
		        }
		        data.add(newRow);
		    }*/

		    return new WebTableData(data);
		}
		    
		  public HashMap<String, String> returnRow(String columnName, String columnValue){
		        for(HashMap<String, String> row : _data){
		            if(row.get(columnName).equals(columnValue)){
		                return row;
		            }
		        }
		        return null;
		    }
		}
