package gurukula.qa.util;

import java.util.Hashtable;


public class GKConstants {

	
	
		public static final boolean GRID_RUN=true;
		
		//paths
		public static final String CHROME_DRIVER_EXE= System.getProperty("user.dir") + "/Chromedriver/chromedriver.exe";
		public static final String FIREFOX_DRIVER_EXE= System.getProperty("user.dir") + "/firefoxdriver/geckodriver.exe";
		
		// locators
		
		//GKHOME-LAUNCHPAGE
		public static final String GKHOME_LOGO = "//*[@class='col-md-8']";//'//*[test()='Welcome to Gurukula!]"'
		public static final String GKHOME_TITLE = "//span[@class='hipster img-responsive img-rounded']";		
		//public static final String LOGIN_LINK = "//a[@href='http://127.0.0.1:8080/#/login']";// AND text()='login']";
		public static final String LOGIN_LINK = "//a[text()='login']";
		//public static final String LOGIN_LINK = "//a[@href='#/login']";
		//public static final String REGISTER_LINK = "//*[@href='http://127.0.0.1:8080/#/register']";// AND text()='Register a new account']";
		public static final String REGISTER_LINK = "//*[text()='Register a new account']";
				
		//LOGINPAGE
		public static final String LPHOME_LOGO = "//img[@src='../../../assets/images/gurukula_v3.png']";
		public static final String LOGIN_TITLE = "//*[@class='col-md-4 col-md-offset-4']";
		public static final String LOGIN_USERNAME = "//input[@id='username']";
		public static final String LOGIN_PASSWORD = "//input[@id='password']";
		public static final String AUTHENTICATE_BUTTON = "//button[text()='Authenticate']";
				
		//ACCOUNTPAGE
		public static final String ACCOUNTHOME_TITLE = "//*[@class='alert alert-success ng-scope ng-binding']";
						
		//TOPMENU
		public static final String HOME_MENU = "//span[text()='Home']";
		public static final String ENTITIES_MENU = "//span[text()='Entities']";
		public static final String ACCOUNT_MENU = "//span[text()='Account']";
		
		//ENTITIES OPTION
		public static final String BRANCH_LINK = "//a[@href='#/branch']";//span[text()='Branch']";
		public static final String STAFF_LINK = "//a[@href='#/staff']";
		
		
		//ACCOUNTS OPTION
		public static final String SETTINGS_LINK = "//span[text()='Settings']";
		public static final String PASSWORD_LINK = "//span[text()='Password']";
		public static final String SESSION_LINK = "//span[text()='Sessions']";
		public static final String LOGOUT_LINK = "//span[text()='Log out']";
		
				
		//BRANCHESPAGE
		public static final String BRANCHES_TITLE = "//h2[text()='Branches']";
		public static final String NEWBRANCHES_LINK = "//span[text()='Create a new Branch']";
		public static final String BRQUERY_VALUE = "//input[@id='searchQuery']";
		public static final String BRSEARCH_LINK = "//span[text()='Search a Branch']";
		public static final String BRSEARCH_PAGE = "//table[@class='table table-striped']"; //*[@class='ng-binding']";
		public static final String BRANCH_ID = "//a[@href='#/branch/1']";
		public static final String BRANCH_COUNT = "//table[@class='table table-striped']/tbody/tr";
		public static final String BRANCH_PAGER = "//ul[@class='pager']";
		public static final String BRANCH_PAGINATION = "//a[@href='#']";
		
		
		//STAFFPAGE
		//public static final String STAFF_PAGE = "//*[@class='container']//*[text()='Staffs']";
		public static final String STAFF_TITLE = "//h2[text()='Staffs']";
		public static final String NEWSTAFF_LINK = "//span[text()='Create a new Staff']";
		public static final String STQUERY_VALUE = "//input[@id='searchQuery']";
		public static final String STSEARCH_LINK = "//span[text()='Search a Staff']";   //Button[@class='btn btn-info']";
		public static final String STSEARCH_PAGE = "//table[@class='table table-striped']"; //*[@class='ng-binding']";
		public static final String STAFF_ID = "//a[@href='#/staff/1']";
		public static final String STAFF_COUNT = "//table[@class='table table-striped']/tbody/tr";
		public static final String STAFF_PAGER = "//ul[@class='pager']";
		public static final String STAFF_PAGINATION = "//a[@href='#']";
		public static final String STAFF_NAME = "//a[@href='#']";
		public static final String STAFF_BRANCH = "//a[@href='#']"; 
				
		//NEWSTAFF
		//public static final String NEWSTAFF_TITLE = "//h4[@id='myStaffLabel']";
		public static final String NEWSTAFF_TITLE = "//h4[text()='Create or edit a Staff']";
		public static final String NEWSTAFF_NAME = "//input[@name='name']";
		public static final String NEWSTAFF_BRANCH= "//select[@name='related_branch']";
		public static final String SAVE_BUTTON= "//span[text()='Save']";
		public static final String CANCEL_BUTTON= "//Button[@class='btn btn-default']";
		
		//NEWBRANCH
		public static final String NEWBRANCH_TITLE = "//h4[text()='Create or edit a Branch']";
		public static final String NEWBRANCH_NAME = "//input[@name='name']";
		public static final String NEWBRANCH_CODE= "//input[@name='code']";
		public static final String BRSAVE_BUTTON= "//span[text()='Save']";
		public static final String BRCANCEL_BUTTON= "//span[text()='Cancel']";//Button[@class='btn btn-default']";
		
		//BUTTONS in BRANCH and STAFF HOME PAGES
		public static final String VIEW_LINK = "//Button[@href='#/staff/1']";
		public static final String BRVIEW_LINK = "//Button[@href='#/branch/1']";
		public static final String EDIT_LINK = "//Button[@class='btn btn-primary btn-sm']";
		public static final String DELETE_LINK = "//Button[@class='btn btn-danger btn-sm']";
		
		//VIEWPAGE
		public static final String VIEW_PAGE = "//span[text()='Branch']";
		public static final String BRANCH_NAME = "//*[@class='input-sm form-control']";
		public static final String BRANCH_CODE = "//*[@class='input-sm form-control']";
		
		//EDITPAGE
		public static final String EDIT_PAGE = "//*[@id='myBranchLabel']"; //*[text()='Create or edit a Branch']";
		public static final String EDIT_NAME = "//input[@name='name']";
		public static final String EDIT_CODE= "//input[@name='code']";
				
		//DELETEPAGE
		public static final String DELETE_PAGE = "//*[@class='modal-title ng-scope']//*[text()='Confirm delete operation']";
		
		
		//SETTINGS
		public static final String SETTINGS_TITLE = "//*[@class='col-md-8 col-md-offset-2']//h2[@class='ng-scope']";
		public static final String FIRST_NAME = "//input[@name='firstName']";
		public static final String LAST_NAME = "//input[@name='lastName']";
		public static final String EMAIL_ID =  "//input[@name='email']";
		public static final String LANGUAGE =  "//select[@name='langKey']";
		public static final String SAVE_CHANGES = "//Button[text()='Save']";
		public static final String SUCCESS_STATUS = "//*[@class='alert alert-success ng-scope ng-hide']";
		public static final String FAILURE_STATUS = "//*[@class='alert alert-danger ng-scope ng-hide']";
		
		//PASSWORD
		public static final String PASSWORD_TITLE = "//*[@class='col-md-8 col-md-offset-2']//h2[@class='ng-scope']";
		public static final String NEW_PASSWORD = "//input[@name='password']";
		public static final String CONFIRM_PASSWORD = "//input[@name='confirmPassword']";
		
		
		//REGISTER
		public static final String REGISTER_TITLE = "//*[@class='col-md-8 col-md-offset-2']";
		public static final String RGHOME_LOGO = "//img[@src='../../../assets/images/gurukula_v3.png']";
		public static final String REG_LOGIN = "//input[@name='login']";
		public static final String REG_EMAILID =  "//input[@name='email']";
		public static final String NEW_PWD =  "//input[@name='password']";
		public static final String CONF_PWD = "//input[@name='confirmPassword']";
		public static final String REGISTER_BUTTON = "//Button[text()='Register']";
		
			
		// URLs - PROD
		public static final String PROD_HOMEPAGE_URL = System.getProperty("user.dir") + "/src/main/java/gurukula/qa/config/Config.properties";
		//public static final String PROD_HOMEPAGE_URL = "/192.168.178.87:8080";
		public static final String PROD_USERNAME = "admin";
		public static final String PROD_PASSWORD = "admin";
		
		// URLs - UAT
		public static final String UAT_HOMEPAGE_URL = "http://127.0.0.1:8080/#/";
		public static final String UAT_USERNAME = "admin";
		public static final String UAT_PASSWORD = "admin";
		
		public static final String ENV="PROD"; //eg.DEV, PROD, UAT
	
		//paths
		public static final String REPORTS_PATH =  System.getProperty("user.dir")+"/ServiceNow/";
		public static final String DATA_XLS_PATH = System.getProperty("user.dir")+"/data/Data.xlsx";
		public static final String TESTDATA_SHEET = "TestData";
		public static final Object RUNMODE_COL = "Runmode";
		public static final String TESTCASES_SHEET = "TestCases";
		
		public static Hashtable<String,String> table;
		
		public static Hashtable<String,String> getEnvDetails(){
			if(table==null){
				table = new Hashtable<String,String>();
				if(ENV.equals("PROD")){
					table.put("url", PROD_HOMEPAGE_URL);
					table.put("username", PROD_USERNAME);
					table.put("password", PROD_PASSWORD);
				}else if(ENV.equals("UAT")){
					table.put("url", UAT_HOMEPAGE_URL);
					table.put("username", UAT_USERNAME);
					table.put("password", UAT_PASSWORD);
				}
				
			}
			return table;
			 
		}


}
