package gurukula.qa.testcases;

	import java.util.concurrent.TimeUnit;

import org.testng.Assert;
	import org.testng.annotations.AfterMethod;
	import org.testng.annotations.BeforeMethod;
	import org.testng.annotations.Test;

	import gurukula.qa.base.TestBase;
	//import gurukula.qa.pages.AccountMenuPage;
	import gurukula.qa.pages.AccountPage;
	//import gurukula.qa.pages.EntitiesPage;
	import gurukula.qa.pages.GeneralSettingsPage;
    import gurukula.qa.pages.LaunchPage;
	import gurukula.qa.pages.LoginPage;
import gurukula.qa.util.TestUtil;

	public class SettingChangeTest extends TestBase{
		LaunchPage launchPage;
		LoginPage loginPage;
		AccountPage accountPage;
		GeneralSettingsPage generalSettingsPage;
		
		public SettingChangeTest() {
			super();
		}

		@BeforeMethod
		public void setup(){
			initialization();
			launchPage = new LaunchPage();
			loginPage = launchPage.gotologin();
			accountPage = loginPage.doLogin(prop.getProperty("username"), prop.getProperty("password"));
			generalSettingsPage = accountPage.clickAccountMenu().clickSettingslink();
			driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
		}
		
		
		@Test(priority=1)
		public void validateSettingPageTitleTest() {
			String title = generalSettingsPage.validateSettingPageTitle();
			Assert.assertEquals(title, "Settings");
		}
			
		@Test(priority=2)	
		public void doSettingsChangeTest() {
			Object Page = generalSettingsPage.doSettingsChange(prop.getProperty("nfname"), prop.getProperty("nlname"),prop.getProperty("nemail"), prop.getProperty("nlangs"));
			//String status = generalSettingsPage.success.getText();
			//Assert.assertEquals(status,"Settings saved");
			if (Page instanceof GeneralSettingsPage)
				System.out.println("Settings changed successfully");
			else
				System.out.println("Setting change Unsuccessful");
			}
			
		@AfterMethod
		public void teardown() {
			driver.quit();
		}

}
