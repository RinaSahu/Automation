package gurukula.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import gurukula.qa.base.TestBase;
import gurukula.qa.pages.AccountPage;
import gurukula.qa.pages.BranchPage;
import gurukula.qa.pages.EntitiesPage;
import gurukula.qa.pages.LaunchPage;
import gurukula.qa.pages.NewBranchPage;
import gurukula.qa.pages.SearchBranchPage;
import gurukula.qa.pages.BranchDeleteConfirmPage;
import gurukula.qa.pages.BranchEditPage;
import gurukula.qa.pages.BranchViewPage;

public class BranchPageTest extends TestBase{
	LaunchPage launchPage;
	AccountPage accountPage;
	EntitiesPage entitiesPage;
	BranchPage branchPage;
	NewBranchPage newBranchPage;
	
	public BranchPageTest() {
		super();
	}

	@BeforeMethod
	public void setup(){
		initialization();
		launchPage = new LaunchPage();
		entitiesPage = launchPage.gotologin().doLogin(prop.getProperty("username"), prop.getProperty("password")).clickEntitiesMenu();
		branchPage= entitiesPage.validateBranchLink();	
		}
	
	
	//validateBranchPageTitle
	
	@Test(priority=1)
	public void validateBranchPageTitleTest() {
		String title = branchPage.validateBranchPageTitle();
		Assert.assertEquals(title, "Branches");
	}
		
	@Test(priority=2)
	public void validateBranchPageHeaderTest() {
		boolean flag= branchPage.validateBranchPageHeader();
		Assert.assertTrue(flag);
	}
	
	@Test(priority=3)
	public void validateNewBranchLinkTest() {
		Object Page = branchPage.validateNewBranchLink();
		if (Page instanceof NewBranchPage)
			System.out.println("New Branch creation Page launched successfully");
		else
			System.out.println("Failure-New Branch creation Page is not launched");
		}
						
	@Test(priority=4)
	public void doBranchSearchTest1() {
		Object Page = branchPage.doBranchSearch(prop.getProperty("branchname"));
		if (Page instanceof SearchBranchPage)
			System.out.println("Search Branch Page by Branchname successfully");
		else
			System.out.println("Failure-Search Branch Page is not launched");
		}
	
	@Test(priority=5)
	public void doBranchSearchTest2() {
		Object Page = branchPage.doBranchSearch(prop.getProperty("branchname"));
		if (Page instanceof SearchBranchPage)
			System.out.println("Search Branch Page by branch name successfully");
		else
			System.out.println("Failure-Search Branch Page is not launched");
		}
	
	
	@Test(priority=6)
	public void validateBranchViewButtonTest() {
		Object Page = branchPage.validateBranchViewButton();
		if (Page instanceof BranchViewPage)
			System.out.println("Branch view Page launched successfully");
		else
			System.out.println("Failure-Branch view Page is not launched");
		}
	
	@Test(priority=7)
	public void validateBranchEditButtonTest() {
		Object Page = branchPage.validateBranchEditButton();
		if (Page instanceof BranchEditPage)
			System.out.println("Branch change Page launched successfully");
		else
			System.out.println("Failure-Branch change Page is not launched");
		}
	
	@Test(priority=8)
	public void validateBranchDeleteButtonTest() {
		Object Page = branchPage.validateBranchDeleteButton();
		if (Page instanceof BranchDeleteConfirmPage)
			System.out.println("Branch delete Page launched successfully");
		else
			System.out.println("Failure-Branch delete Page is not launched");
		}
	
	@Test(priority=9)
	public void validateBranchidButtonTest() {
		Object Page = branchPage.validateBranchidButton();
		if (Page instanceof BranchViewPage)
			System.out.println("Branch View Page launched successfully");
		else
			System.out.println("Failure-Branch View Page is not launched");
		}
	
		//validateBranchPagination,validateBranchPager
	
	@Test(priority=10)
	public void validateBranchPagerTest() {
		boolean flag= branchPage.validateBranchPager();
		Assert.assertTrue(flag);
	}
	
	@Test(priority=11)
	public void validateBranchPaginationTest() {
		Object Page = branchPage.validateBranchPagination();
		if (Page instanceof BranchPage)
			System.out.println("Branch Page moved successfully");
		else
			System.out.println("Failure-Branch Page is not moving");
	}
	
	@Test(priority=12)
	public void findLastIDTest() {
		int e = branchPage.findLastID();
		Assert.assertEquals(e, 7);
	}
	
	
		@AfterMethod
	public void teardown() {
		driver.quit();
	}

}

	

