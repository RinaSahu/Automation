package gurukula.qa.testcases;

import org.testng.annotations.Test;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import gurukula.qa.base.TestBase;
import gurukula.qa.pages.AccountPage;
import gurukula.qa.pages.LaunchPage;
import gurukula.qa.pages.RegistrationPage;

public class RegistrationPageTest extends TestBase{
	    RegistrationPage registerPage;
		LaunchPage launchPage;	
		
		public RegistrationPageTest() {
			super();
		}
	
		@BeforeMethod
		public void setup(){
			initialization();
			launchPage = new LaunchPage();
			registerPage = launchPage.gotoRegister();
			
			}
		@Test(priority=1)
		public void validateregisterPageTitleTest() {
			String rgtitle = registerPage.validateregisterPageTitle();
			Assert.assertEquals(rgtitle, "Registration");
		}
		
		@Test(priority=2)
		public void validateregLogoTest() {
			boolean flag = registerPage.validateregLogo();
			Assert.assertTrue(flag);
		}
		
		@Test(priority=3)
		public void validateregisterPageHeaderTest() {
			boolean flag = registerPage.validateregisterPageHeader();
			Assert.assertTrue(flag);
		}
		
		@Test(priority=4)
		public void doregisterTest() {			
		Object Page = registerPage.doregister(prop.getProperty("username1"), prop.getProperty("email"), prop.getProperty("password1"), prop.getProperty("password1"));
				if (Page instanceof AccountPage) {
				System.out.println("Registration is successful");
				}	
			else
				System.out.println("Registration Unsuccessful");
			}
				
		@AfterMethod
		public void teardown() {
			driver.quit();
		}
	
}
