package gurukula.qa.testcases;

import org.testng.annotations.Test;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import gurukula.qa.base.TestBase;
import gurukula.qa.pages.AccountMenuPage;
import gurukula.qa.pages.AccountPage;
import gurukula.qa.pages.LaunchPage;
import gurukula.qa.pages.LoginPage;

public class LoginLogoutPageTest extends TestBase{
		LoginPage loginPage;
		AccountPage accountPage;
		LaunchPage launchPage;	
		AccountMenuPage accountMenuPage;
		
		public LoginLogoutPageTest() {
			super();
		}
	
		@BeforeMethod
		public void setup(){
			initialization();
			launchPage = new LaunchPage();
			loginPage = launchPage.gotologin();
			
			}
		@Test(priority=1)
		public void validateLoginPageTitleTest() {
			String title = loginPage.validateLoginPageTitle();
			Assert.assertEquals(title, "Authentication");
		}
		
		@Test(priority=2)
		public void validateLogoTest() {
			boolean flag = loginPage.validateLogo();
			Assert.assertTrue(flag);
		}
		
		@Test(priority=3)
		public void validateLoginPageHeaderTest() {
			boolean flag = loginPage.validateLoginPageHeader();
			Assert.assertTrue(flag);
		}
		
		@Test(priority=4)
		public void loginTest() {
			
			//accountPage = loginPage.doLogin(prop.getProperty("username"), prop.getProperty("password"));
			
		//}
			
		/*boolean status = accountPage.validateAccountPageTitle();
		if (status){
			System.out.println("Logged in successfully");
		}
		System.out.println("Unsuccessful");*/
		Object Page = loginPage.doLogin(prop.getProperty("username"), prop.getProperty("password"));
			if (Page instanceof AccountPage)
				System.out.println("Logged in successfully");
			else
				System.out.println("Login Unsuccessful");
			}
				
		@Test(priority=5)
		public void logoutTest() {
			
			accountPage = loginPage.doLogin(prop.getProperty("username"), prop.getProperty("password"));
			//accountPage = new AccountPage();
			Object Page = accountPage.clickAccountMenu().clickLogoutLink();
			if (Page instanceof LaunchPage)
				System.out.println("Logged out successfully");
			else
				System.out.println("logout Unsuccessful");
			}
			
		@AfterMethod
		public void teardown() {
			driver.quit();
		}
	
}
