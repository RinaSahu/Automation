package gurukula.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import gurukula.qa.base.TestBase;
import gurukula.qa.pages.AccountPage;
import gurukula.qa.pages.EntitiesPage;
import gurukula.qa.pages.LaunchPage;
import gurukula.qa.pages.NewStaffPage;
import gurukula.qa.pages.SearchStaffPage;
import gurukula.qa.pages.StaffDeleteConfirmPage;
import gurukula.qa.pages.StaffEditPage;
import gurukula.qa.pages.StaffPage;
import gurukula.qa.pages.StaffViewPage;

public class StaffPageTest extends TestBase{
	LaunchPage launchPage;
	AccountPage accountPage;
	EntitiesPage entitiesPage;
	StaffPage staffPage;
	NewStaffPage newStaffPage;
	
	public StaffPageTest() {
		super();
	}

	@BeforeMethod
	public void setup(){
		initialization();
		launchPage = new LaunchPage();
		entitiesPage = launchPage.gotologin().doLogin(prop.getProperty("username"), prop.getProperty("password")).clickEntitiesMenu();
		staffPage= entitiesPage.validateStaffLink();	
		}
	
	
	//validateStaffPageTitle
	
	@Test(priority=1)
	public void validateStaffPageTitleTest() {
		String title = staffPage.validateStaffPageTitle();
		Assert.assertEquals(title, "Staffs");
	}
		
	@Test(priority=2)
	public void validateStaffPageHeaderTest() {
		boolean flag= staffPage.validateStaffPageHeader();
		Assert.assertTrue(flag);
	}
	
	@Test(priority=3)
	public void validateNewStaffLinkTest() {
		Object Page = staffPage.validateNewStaffLink();
		if (Page instanceof NewStaffPage)
			System.out.println("New Staff creation Page launched successfully");
		else
			System.out.println("Failure-New Staff creation Page is not launched");
		}
						
	@Test(priority=4)
	public void doStaffSearchTest1() {
		Object Page = staffPage.doStaffSearch(prop.getProperty("qstaffname"));
		String id = staffPage.staffid.getText();
		Assert.assertEquals(id, "1");
		if (Page instanceof SearchStaffPage)
			System.out.println("Search Staff Page by staffname successfully");
		else
			System.out.println("Failure-Search Staff Page is not launched");
		}
	
	@Test(priority=5)
	public void doStaffSearchTest2() {
		Object Page = staffPage.doStaffSearch(prop.getProperty("branchname"));
		if (Page instanceof SearchStaffPage)
			System.out.println("Search Staff Page by branch name successfully");
		else
			System.out.println("Failure-Search Staff Page is not launched");
		
		
		/*Boolean assertTrue = driver.findElements(By.id("textfield")).contains("Additional Appeal'sInformation");

		 if (assertTrue == true) {System.out.print("Yes"); }else{System.out.print("No");}*/
		}
	
	
	@Test(priority=6)
	public void validateStaffViewButtonTest() {
		Object Page = staffPage.validateStaffViewButton();
		if (Page instanceof StaffViewPage)
			System.out.println("Staff view Page launched successfully");
		else
			System.out.println("Failure-Staff view Page is not launched");
		
		}
	
	@Test(priority=7)
	public void validateStaffEditButtonTest() {
		Object Page = staffPage.validateStaffEditButton();
		if (Page instanceof StaffEditPage)
			System.out.println("Staff change Page launched successfully");
		else
			System.out.println("Failure-Staff change Page is not launched");
		}
	
	@Test(priority=8)
	public void validateStaffDeleteButtonTest() {
		Object Page = staffPage.validateStaffDeleteButton();
		if (Page instanceof StaffDeleteConfirmPage)
			System.out.println("Staff delete Page launched successfully");
		else
			System.out.println("Failure-Staff delete Page is not launched");
		}
	
	@Test(priority=9)
	public void validateStaffidButtonTest() {
		Object Page = staffPage.validateStaffidButton();
		if (Page instanceof StaffViewPage)
			System.out.println("Staff View Page launched successfully");
		else
			System.out.println("Failure-Staff View Page is not launched");
		}
	
			
	@Test(priority=10)
	public void validateStaffPagerTest() {
		boolean flag= staffPage.validateStaffPager();
		Assert.assertTrue(flag);
	}
	
	@Test(priority=11)
	public void validateStaffPaginationTest() {
		Object Page = staffPage.validateStaffPagination();
		if (Page instanceof StaffPage)
			System.out.println("Staff Page moved successfully");
		else
			System.out.println("Failure-Staff Page is not moving");
	}
	
	@Test(priority=12)
	public void findLastIDTest() {
		int e = staffPage.findLastID();
		Assert.assertEquals(e, 13);
	}
	
	
		@AfterMethod
	public void teardown() {
		driver.quit();
	}

}

	

