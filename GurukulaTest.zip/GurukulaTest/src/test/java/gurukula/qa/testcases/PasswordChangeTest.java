package gurukula.qa.testcases;

	import java.util.concurrent.TimeUnit;

import org.testng.Assert;
	import org.testng.annotations.AfterMethod;
	import org.testng.annotations.BeforeMethod;
	import org.testng.annotations.Test;

	import gurukula.qa.base.TestBase;
	//import gurukula.qa.pages.AccountMenuPage;
	import gurukula.qa.pages.AccountPage;
import gurukula.qa.pages.ChangePasswordPage;
//import gurukula.qa.pages.EntitiesPage;
	
    import gurukula.qa.pages.LaunchPage;
	import gurukula.qa.pages.LoginPage;
import gurukula.qa.util.TestUtil;

	public class PasswordChangeTest extends TestBase{
		LaunchPage launchPage;
		LoginPage loginPage;
		AccountPage accountPage;
		ChangePasswordPage changePasswordPage;
		
		public PasswordChangeTest() {
			super();
		}

		@BeforeMethod
		public void setup(){
			initialization();
			launchPage = new LaunchPage();
			loginPage = launchPage.gotologin();
			accountPage = loginPage.doLogin(prop.getProperty("username"), prop.getProperty("password"));
			changePasswordPage = accountPage.clickAccountMenu().clickPasswordLink();
			driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
		}
		
		
		@Test(priority=1)
		public void validatePassowordPageTitleTest() {
			String title = changePasswordPage.validatePassowordPageTitle();
			Assert.assertEquals(title, "Passowrd");
					}
			
		@Test(priority=2)	
		public void doPasswordChangeTest() {
			Object Page = changePasswordPage.doPasswordChange(prop.getProperty("newpwd"), prop.getProperty("cnfpwd"));
			if (Page instanceof ChangePasswordPage)
				System.out.println("Password changed successfully");
			else
				System.out.println("Password change Unsuccessful");
			}
			
		@AfterMethod
		public void teardown() {
			driver.quit();
		}

}
