package gurukula.qa.testcases;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import gurukula.qa.base.TestBase;
import gurukula.qa.pages.AccountPage;
import gurukula.qa.pages.EntitiesPage;
import gurukula.qa.pages.LaunchPage;
import gurukula.qa.pages.StaffEditPage;
import gurukula.qa.pages.StaffPage;
import gurukula.qa.util.TestUtil;

public class StaffEditTest extends TestBase{
	LaunchPage launchPage;
	AccountPage accountPage;
	EntitiesPage entitiesPage;
	StaffPage staffPage;
	StaffEditPage staffEditPage;
	
	public StaffEditTest() {
		super();
	}

	@BeforeMethod
	public void setup(){
		initialization();
		launchPage = new LaunchPage();
		entitiesPage = launchPage.gotologin().doLogin(prop.getProperty("username"), prop.getProperty("password")).clickEntitiesMenu();
		staffEditPage = entitiesPage.validateStaffLink().validateStaffEditButton();
		//driver.switchTo().frame("ModelFrameTitle");
		driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
		driver.switchTo().activeElement();
		}
	
	
	@Test(priority=1)
	public void validateEditStaffModalTitleTest() {
		String title = staffEditPage.validateEditStaffModalTitle();
		Assert.assertEquals(title, "Create or edit a Staff");
		}
	
	@Test(priority=2)
	public void doStaffEditTest() {
		
		Object Page = staffEditPage.doStaffEdit(prop.getProperty("newstaffname"), prop.getProperty("newstaffbranch"));
		if (Page instanceof StaffPage)
			System.out.println("New Staff created successfully");
		else
			System.out.println("Failure-New Staff is not created");
		
		driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
		driver.switchTo().activeElement();
		
		//int nstaffid = staffPage.findLastID();
		//System.out.println("New Staff id should be " +nstaffid);
		//Assert.assertEquals(nstaffid,8);
		//Assert.assertEquals(prop.getProperty("newstaffbranch"), prop.getProperty("newstaffbranch"));
		}
						
	@Test(priority=3)
	public void doStaffEditnCancelTest() {
		Object Page = staffEditPage.doStaffEditCancel(prop.getProperty("newstaffname"), prop.getProperty("newstaffbranch"));
		if (Page instanceof StaffPage)
			System.out.println("cancelled successfully");
		else
			System.out.println("Failure-cancel not working");
		/*t int e = staffPage.findLastID();
		Assert.assertEquals(e, 13);*/
		}
	
	
		@AfterMethod
	public void teardown() {
			driver.quit();
	}

}
