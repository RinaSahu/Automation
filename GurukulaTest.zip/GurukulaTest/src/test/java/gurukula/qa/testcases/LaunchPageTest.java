package gurukula.qa.testcases;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import gurukula.qa.base.TestBase;
import gurukula.qa.pages.LaunchPage;
import gurukula.qa.pages.LoginPage;

public class LaunchPageTest extends TestBase{
		LoginPage loginPage;
		LaunchPage launchPage;
		
		
		public LaunchPageTest() {
			super();
		}
	
		@BeforeMethod
		public void setup(){
			initialization();
			launchPage = new LaunchPage();
		}
		
		@Test(priority=1)
		public void validateLaunchPageTitleTest() {
			String title = launchPage.validateLaunchPageTitle();
			Assert.assertEquals(title, "gurukula");
		}
		
		@Test(priority=2)
		public void validateLoginPageTitleTest() {
			boolean flag= launchPage.validateLoginPageTitle();
			Assert.assertTrue(flag);
		}
		
		@Test(priority=3)
		public void validateGKLogoTest() {
			boolean flag= launchPage.validateGKLogo();
			Assert.assertTrue(flag);
		}
				
		@Test(priority=4)
		public void validateloginLinkTest() {
			boolean flag= launchPage.validateloginLink();
			Assert.assertTrue(flag);
		}
				
		@Test(priority=5)
		public void validateRegisterLinkTest() {
			boolean flag= launchPage.validateRegisterLink();
			Assert.assertTrue(flag);
		}
		@Test(priority=6)
		public void validateHomeMenuTest() {
			boolean flag= launchPage.validateHomeMenu();
			Assert.assertTrue(flag);
		}
		@Test(priority=7)
		public void validateAccountMenuTest() {
			boolean flag= launchPage.validateAccountMenu();
			Assert.assertTrue(flag);
		}
		
		@Test(priority=8)
		public void gotologinTest() {
			loginPage = launchPage.gotologin();
		//String title = loginPage.driver.verifyTitle("gurukula");	
		}
		
			@AfterMethod
		public void teardown() {
			driver.quit();
		}
	
}
