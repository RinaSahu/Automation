package gurukula.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import gurukula.qa.base.TestBase;
import gurukula.qa.pages.AccountMenuPage;
import gurukula.qa.pages.AccountPage;
import gurukula.qa.pages.EntitiesPage;
import gurukula.qa.pages.LaunchPage;
import gurukula.qa.pages.LoginPage;

public class AccountPageTest extends TestBase{
	LaunchPage launchPage;
	LoginPage loginPage;
	AccountPage accountPage;
	EntitiesPage entitiesPage;
	AccountMenuPage accountMenuPage;
	
	public AccountPageTest() {
		super();
	}

	@BeforeMethod
	public void setup(){
		initialization();
		launchPage = new LaunchPage();
		loginPage = launchPage.gotologin();
		loginPage = new LoginPage();
		accountPage = loginPage.doLogin(prop.getProperty("username"), prop.getProperty("password"));
	}
	
	
	@Test(priority=1)
	public void validateAccountPageTitleTest() {
		String title = accountPage.validateAccountPageTitle();
		Assert.assertEquals(title, "gurukula");
	}
	
	@Test(priority=2)
	public void validateAccountPageHeaderTest() {
		boolean flag= accountPage.validateAccountPageHeader();
		Assert.assertTrue(flag);
	}
	
	@Test(priority=3)
	public void validateAccountPageLogoTest() {
		boolean flag= accountPage.validateAccountPageLogo();
		Assert.assertTrue(flag);
	}
			
	@Test(priority=4)
	public void clickHomeMenuTest() {
		accountPage = accountPage.clickHomeMenu();
		
	}
			
	@Test(priority=5)
	public void clickEntitiesMenuTest() {
		entitiesPage = accountPage.clickEntitiesMenu();
	}
	
	@Test(priority=6)
	public void clickAccountMenuTest() {
		accountMenuPage = accountPage.clickAccountMenu();
		
	}
		
		@AfterMethod
	public void teardown() {
		driver.quit();
	}

}

	

