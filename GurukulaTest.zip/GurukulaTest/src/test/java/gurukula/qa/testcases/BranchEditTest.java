package gurukula.qa.testcases;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import gurukula.qa.base.TestBase;
import gurukula.qa.pages.AccountPage;
import gurukula.qa.pages.BranchEditPage;
import gurukula.qa.pages.EntitiesPage;
import gurukula.qa.pages.LaunchPage;
import gurukula.qa.pages.BranchPage;
import gurukula.qa.util.TestUtil;

public class BranchEditTest extends TestBase{
	LaunchPage launchPage;
	AccountPage accountPage;
	EntitiesPage entitiesPage;
	BranchPage branchPage;
	BranchEditPage branchEditPage;
	
	public BranchEditTest() {
		super();
	}

	@BeforeMethod
	public void setup(){
		initialization();
		launchPage = new LaunchPage();
		entitiesPage = launchPage.gotologin().doLogin(prop.getProperty("username"), prop.getProperty("password")).clickEntitiesMenu();
		branchEditPage = entitiesPage.validateBranchLink().validateBranchEditButton();
		
		//driver.switchTo().frame("ModelFrameTitle");
		driver.switchTo().activeElement();
		driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
		driver.switchTo().activeElement();
		}
	
	
	@Test(priority=1)
	public void validateEditBranchModalTitleTest() {
		String title = branchEditPage.validateEditBranchModalTitle();
		Assert.assertEquals(title, "Create or edit a Branch");
		}
	
	@Test(priority=2)
	public void doBranchCreationTest() {
		
		Object Page = branchEditPage.doBranchCreation(prop.getProperty("newbranchname"), prop.getProperty("newbranchcode"));
		if (Page instanceof BranchPage)
			System.out.println("Branch details changed successfully");
		else
			System.out.println("Failure-Branch details not changed");
		
		driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
		driver.switchTo().activeElement();
		
		//int nBranchid = branchPage.findLastID();
		//System.out.println("New Branch id should be " +nBranchid);
		//Assert.assertEquals(nBranchid,8);
		//Assert.assertEquals(prop.getProperty("newBranchbranch"), prop.getProperty("newBranchbranch"));
		}
						
	@Test(priority=3)
	public void doBranchCreationCancelTest() {
		Object Page = branchEditPage.doBranchCreationCancel(prop.getProperty("newbranchname"), prop.getProperty("newbranchcode"));
		if (Page instanceof BranchPage)
			System.out.println("cancelled successfully");
		else
			System.out.println("Failure-cancel not working");
		}
	
	
		@AfterMethod
	public void teardown() {
			driver.quit();
	}

}
